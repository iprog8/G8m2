
function ADatClickPeMine() {
    alert('AUUUUU... m-a click-uit!!!');
}

function Auu() {
    console.log('Am interceptat dublu click');
}
