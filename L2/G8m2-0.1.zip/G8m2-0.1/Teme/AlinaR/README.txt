Salut,
1. In acest folder vei posta temele.
2. Pentru fiecare laborator faci un folder separat de tipul L1 sau Laborator1 in care vei pune tema

Spor la invatat HTML, CSS si JavaScript!